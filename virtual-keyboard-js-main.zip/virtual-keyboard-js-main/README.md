# virtual-keyboard-js
The virtual keyboard is integerated in index.html
